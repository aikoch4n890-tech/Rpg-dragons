// Lógica do menu: renderiza abas, lista e detalhes a partir de MENU_DATA.
(function () {
  const state = { cat: 0, entry: 0 };

  const $tabs = document.getElementById("tabs");
  const $list = document.getElementById("list");
  const $title = document.getElementById("category-title");
  const $name = document.getElementById("detail-name");
  const $desc = document.getElementById("detail-desc");
  const $stat = document.getElementById("detail-stat");

  function el(tag, className, text) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text !== undefined) node.textContent = text;
    return node;
  }

  function render() {
    const cat = MENU_DATA[state.cat];
    const entry = cat.entries[state.entry];

    $title.textContent = cat.label;
    $name.textContent = entry.name;
    $desc.textContent = entry.desc;
    $stat.textContent = entry.stat;

    $tabs.replaceChildren(
      ...MENU_DATA.map((c, i) => {
        const b = el("button", "row row--tab" + (i === state.cat ? " is-active" : ""), c.label);
        b.type = "button";
        b.setAttribute("aria-current", i === state.cat ? "true" : "false");
        b.addEventListener("click", () => select(i, 0));
        return b;
      })
    );

    $list.replaceChildren(
      ...cat.entries.map((e, i) => {
        const b = el("button", "row row--item" + (i === state.entry ? " is-active" : ""));
        b.type = "button";
        b.append(el("span", "", e.name), el("span", "meta", e.meta));
        b.addEventListener("click", () => select(state.cat, i));
        return b;
      })
    );
  }

  function select(cat, entry) {
    state.cat = cat;
    state.entry = entry;
    render();
  }

  // Teclado: setas ↑/↓ mudam o item; ←/→ (ou Q/E) mudam a aba.
  document.addEventListener("keydown", (ev) => {
    const count = MENU_DATA.length;
    const items = MENU_DATA[state.cat].entries.length;
    if (ev.key === "ArrowDown") select(state.cat, (state.entry + 1) % items);
    else if (ev.key === "ArrowUp") select(state.cat, (state.entry - 1 + items) % items);
    else if (ev.key === "ArrowRight" || ev.key.toLowerCase() === "e") select((state.cat + 1) % count, 0);
    else if (ev.key === "ArrowLeft" || ev.key.toLowerCase() === "q") select((state.cat - 1 + count) % count, 0);
    else return;
    ev.preventDefault();
  });

  render();
})();
