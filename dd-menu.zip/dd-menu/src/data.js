// Conteúdo do menu. Edite aqui para trocar abas, itens e textos.
// Cada aba tem: label e entries[{ name, meta, desc, stat }].
const MENU_DATA = [
  { label: "Itens", entries: [
    { name: "Poção de cura", meta: "x 6", desc: "Restaura uma parte da vitalidade. Beber leva alguns segundos.", stat: "Peso 0,3" },
    { name: "Erva verde", meta: "x 14", desc: "Planta comum de campo. Pode ser combinada para criar remédios.", stat: "Peso 0,1" },
    { name: "Tocha", meta: "x 3", desc: "Ilumina o caminho à noite e em cavernas. Queima por tempo limitado.", stat: "Peso 1,0" },
    { name: "Corda reforçada", meta: "x 1", desc: "Útil para escalar e atravessar vãos.", stat: "Peso 2,5" }
  ] },
  { label: "Equipamento", entries: [
    { name: "Espada longa", meta: "Mão direita", desc: "Lâmina equilibrada, boa para quem está começando a jornada.", stat: "Ataque 42" },
    { name: "Escudo de madeira", meta: "Mão esquerda", desc: "Reforçado com aro de ferro. Aguenta golpes leves.", stat: "Defesa 18" },
    { name: "Manto de viajante", meta: "Corpo", desc: "Tecido grosso, protege do frio e da chuva.", stat: "Defesa 6" }
  ] },
  { label: "Habilidades", entries: [
    { name: "Corte ascendente", meta: "Nv. 2", desc: "Golpe que lança o alvo para o alto, abrindo espaço para o ataque seguinte.", stat: "Custo 20" },
    { name: "Investida", meta: "Nv. 1", desc: "Avanço rápido com a arma em punho.", stat: "Custo 15" },
    { name: "Guarda firme", meta: "Nv. 3", desc: "Reduz o recuo ao defender com o escudo.", stat: "Passiva" }
  ] },
  { label: "Companheiros", entries: [
    { name: "Companheiro principal", meta: "Nv. 12", desc: "Luta ao seu lado e aprende com as suas escolhas durante a jornada.", stat: "Vocação: Guerreiro" },
    { name: "Companheiro de apoio", meta: "Nv. 10", desc: "Cura aliados e conhece os caminhos da região.", stat: "Vocação: Clérigo" }
  ] },
  { label: "Mapa", entries: [
    { name: "Região atual", meta: "Vale do Norte", desc: "Estrada antiga cercada por floresta. Perigosa depois do anoitecer.", stat: "Pontos descobertos 7 / 15" },
    { name: "Pontos de viagem", meta: "3", desc: "Locais já visitados aos quais você pode retornar.", stat: "Custo por viagem 200" }
  ] },
  { label: "Diário", entries: [
    { name: "A estrada esquecida", meta: "Em andamento", desc: "Encontre o mensageiro desaparecido antes que a noite chegue.", stat: "Recomendado Nv. 10" },
    { name: "Ervas para o boticário", meta: "Concluída", desc: "Entregue quinze ervas verdes ao boticário da vila.", stat: "Recompensa 300" }
  ] },
  { label: "Sistema", entries: [
    { name: "Salvar jogo", meta: "", desc: "Grava o progresso atual no espaço selecionado.", stat: "" },
    { name: "Opções", meta: "", desc: "Ajuste som, controles e legendas.", stat: "" },
    { name: "Voltar ao título", meta: "", desc: "Progresso não salvo será perdido.", stat: "" }
  ] }
];
