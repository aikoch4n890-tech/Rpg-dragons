# Menu de jogo (estilo RPG medieval)

Base de menu para jogo, em HTML, CSS e JavaScript puros, sem dependências nem build.
Tema escuro com linhas douradas e fontes serifadas.

## Como rodar

Abra `index.html` no navegador. Ou, com um servidor local:

```bash
python3 -m http.server 8000
# depois abra http://localhost:8000
```

## Estrutura

```
index.html        página e estrutura do menu
src/styles.css    visual (cores e fontes ficam nas variáveis do :root)
src/data.js       conteúdo: abas, itens e textos
src/menu.js       lógica: troca de aba, seleção e atalhos de teclado
```

## Controles

- Clique/toque nas abas e itens
- Teclado: ↑ ↓ mudam o item, ← → (ou Q / E) mudam a aba

## Ideias de próximos passos

- Menu circular de acesso rápido
- Inventário em grade
- Sons e animações de transição
- Portar para Unity, Godot ou Unreal
- Ligar ao estado real do jogo (hoje os dados são de exemplo)
