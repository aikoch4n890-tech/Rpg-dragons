# CLAUDE.md

Instruções para o Claude Code neste projeto.

## O que é
Menu de jogo em estilo RPG medieval, em HTML/CSS/JS puros. Sem build, sem dependências.

## Estrutura
- `index.html`: estrutura da página
- `src/styles.css`: visual; cores e fontes nas variáveis do `:root`
- `src/data.js`: conteúdo (`MENU_DATA`: abas, itens, textos)
- `src/menu.js`: renderização e atalhos de teclado

## Regras
- Responder e escrever textos de interface em português do Brasil.
- Manter JS puro e sem bibliotecas, a menos que eu peça.
- Mudanças de conteúdo vão em `src/data.js`; mudanças visuais em `src/styles.css`. Evite estilos inline.
- Usar `<button>` reais para tudo que é clicável. Alvos de toque de pelo menos 44px. Manter contraste legível.
- Não copiar arte, nomes, logos ou textos de jogos existentes. É só inspiração de estilo.
- Testar abrindo `index.html` (ou `python3 -m http.server`) e conferir no tamanho de celular e de desktop.

## Ideias pendentes
Menu circular de acesso rápido, inventário em grade, sons, animações.
